@extends('layouts.app')

@section('title', $evento->titulo . ' — FalaQ')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-5 gap-6">
    <!-- Formulário de envio de Pergunta -->
    <div class="md:col-span-2">
        <div class="bg-gray-900 border border-gray-700 rounded-xl shadow-lg p-6">
            <h4 class="text-xl font-bold mb-5">💬 Faça sua Pergunta</h4>

            <form action="{{ route('eventos.perguntas.store', $evento->id) }}" method="POST">
                <input type="hidden" name="evento_id" value="{{ $evento->id }}">
                @csrf

                <div class="mb-4">
                    <label for="texto" class="block mb-2 text-sm font-medium text-gray-300">
                        Texto da Pergunta
                    </label>

                    <textarea
                        name="texto"
                        id="texto"
                        rows="5"
                        class="w-full rounded-md bg-gray-800 text-white border border-gray-600 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 @error('texto') border-red-500 @enderror"
                        placeholder="Digite sua dúvida ou comentário para o palestrante..."
                    >{{ old('texto') }}</textarea>

                    @error('texto')
                        <p class="mt-2 text-sm font-bold text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <button
                    type="submit"
                    class="w-full bg-blue-600 text-white px-4 py-2 rounded-md font-bold hover:bg-blue-700 transition-colors"
                >
                    Enviar Pergunta
                </button>
            </form>
        </div>
    </div>

    <!-- Lista de Perguntas -->
    <div class="md:col-span-3">
        <div class="flex justify-between items-center mb-4">
            <h4 class="text-xl font-bold m-0">📋 Perguntas do Evento</h4>
            <span class="text-gray-400 text-sm">
                Total no Banco: {{ $evento->perguntas()->count() }}
            </span>
        </div>

        <div class="space-y-4">
            @forelse($perguntas as $pergunta)
                <div class="bg-gray-900 border border-gray-700 rounded-xl shadow-md p-5 mb-4">
                    <p class="text-lg mb-3 text-white">{{ $pergunta->texto }}</p>

                    <p class="mb-3 text-gray-400 text-sm">
                        Autor: {{ $pergunta->user->name ?? 'Anônimo' }}
                    </p>

                    <div class="flex justify-between items-center text-gray-400 text-sm">
                        <span>
                            Status:
                            <span class="inline-block bg-green-600 text-white px-2 py-1 rounded-md text-xs">
                                {{ $pergunta->status }}
                            </span>
                        </span>
                        <span>{{ $pergunta->created_at->format('d/m/Y H:i') }}</span>
                    </div>
                </div>
            @empty
                <div class="bg-gray-900 border border-gray-700 rounded-xl text-center p-6">
                    Nenhuma pergunta enviada ainda. Seja o primeiro!
                </div>
            @endforelse
        </div>

        <div class="flex justify-center mt-6">
            {{ $perguntas->links() }}
        </div>
    </div>
</div>
@endsection
