<?php

namespace App\Policies;

use App\Models\Pergunta;
use App\Models\User;

class PerguntaPolicy
{
    /**
     * Permite excluir a pergunta se o usuário for o autor
     * ou o dono do evento ao qual ela pertence.
     */
    public function delete(User $user, Pergunta $pergunta): bool
    {
        return $user->id === $pergunta->user_id
            || ($pergunta->evento?->user_id !== null
                && $user->id === $pergunta->evento->user_id);
    }
}
