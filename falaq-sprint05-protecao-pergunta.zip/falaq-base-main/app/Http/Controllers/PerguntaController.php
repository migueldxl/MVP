<?php

namespace App\Http\Controllers;

use App\Models\Pergunta;

class PerguntaController extends Controller
{
    public function votar(Pergunta $pergunta)
    {
        $pergunta->votos()->toggle(auth()->id());

        return back()
            ->with('sucesso', 'Voto atualizado com sucesso!')
            ->with('status', 'Voto atualizado com sucesso!');
    }
}
