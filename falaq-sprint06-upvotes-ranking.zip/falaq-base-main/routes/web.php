<?php

use App\Http\Controllers\EventoController;
use App\Http\Controllers\PerguntaController;
use Illuminate\Support\Facades\Route;

Route::get('/', [EventoController::class, 'index'])->name('eventos.index');
Route::get('/eventos/{id}', [EventoController::class, 'show'])->name('eventos.show');
Route::post('/eventos/{id}/perguntas', [EventoController::class, 'storePergunta'])
    ->middleware('auth')
    ->name('eventos.perguntas.store');

Route::post('/perguntas/{pergunta}/votar', [PerguntaController::class, 'votar'])
    ->middleware('auth')
    ->name('perguntas.votar');
